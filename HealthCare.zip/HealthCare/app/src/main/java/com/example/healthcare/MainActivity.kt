package com.example.healthcare

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {
    private var mFirebaseAuth: FirebaseAuth? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dangnhap)
        mFirebaseAuth = FirebaseAuth.getInstance()
        val dangnhap = findViewById<Button>(R.id.dangnhap)
        dangnhap.setOnClickListener {
            val username = findViewById<EditText>(R.id.username).text.toString()
            val password = findViewById<EditText>(R.id.password).text.toString()
            if (TextUtils.isEmpty(username) && TextUtils.isEmpty(password)) {
            } else loginAccount(username, password)

        }
    }

    private fun loginAccount(
        username: String,
        password: String,
    ) {
        mFirebaseAuth!!.signInWithEmailAndPassword(username, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = mFirebaseAuth!!.currentUser
                    updateUI(user)
                    val intent = Intent(this, View::class.java)
                    startActivity(intent)
                    Toast.makeText(applicationContext, "Login Success", Toast.LENGTH_SHORT).show()
                    } else {
                    updateUI(null)
                }

            }
        }
        private fun updateUI(user: FirebaseUser?) {

        }

    }
package com.example.healthcare

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.firebase.database.*

class View : AppCompatActivity() {
    private var data: DatabaseReference? = null
    private var dataFirebase: DatabaseReference? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val Sp02Tv = findViewById<TextView>(R.id.Sp02Tv)
        val BpmTv = findViewById<TextView>(R.id.BpmTv)
        data = FirebaseDatabase.getInstance().reference
        dataFirebase = FirebaseDatabase.getInstance().getReference("Sp02")
        dataFirebase!!.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val temp: String = dataSnapshot.getValue().toString()
                Sp02Tv.text = temp

//                val valueTemp = temp.toFloat()
//                if (valueTemp > 37) tempIM.startAnimation(blink)


            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
        data = FirebaseDatabase.getInstance().reference
        dataFirebase = FirebaseDatabase.getInstance().getReference("Bpm")
        dataFirebase!!.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val temp: String = dataSnapshot.getValue().toString()
                BpmTv.text = temp

//                val valueTemp = temp.toFloat()
//                if (valueTemp > 37) tempIM.startAnimation(blink)


            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })

    }
}